const products = [
  { id: 1, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_1.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 2, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_2.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 3, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_3.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 4, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_4.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 5, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_5.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 6, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_6.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 7, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_3.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 8, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_1.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] },
  { id: 9, name: "Nome do óculos", price: 159.90, image: "/static/img/produto_5.png", hoverImage: "", colors: ["#27272a", "#d4d4d8", "#fb923c"] }
];

const CART_STORAGE_KEY = "zilli_cart";
const DEFAULT_HOVER_IMAGE = "/static/img/modelo.png";
const CHECKOUT_BUTTON_DEFAULT_TEXT = "Seguir para pagamento";

let toastTimer = null;
let isSubmittingCheckout = false;

/* ===== Helpers ===== */
function formatPrice(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function getCart() {
  try {
    const cart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY));
    return Array.isArray(cart) ? cart : [];
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
}

function getCartCount(cart) {
  return cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
}

function findCartItem(cart, productId) {
  return cart.find((i) => i.id === productId);
}

function getInputValue(id) {
  return document.getElementById(id)?.value?.trim() || "";
}

function onlyDigits(value) {
  return (value || "").replace(/\D/g, "");
}

function showToast(message = "Adicionado à sacola") {
  const toast = document.getElementById("toast");
  const toastText = document.getElementById("toastText");
  if (!toast || !toastText) return;

  toastText.textContent = message;
  toast.classList.remove("hidden", "hide");
  toast.classList.add("show");

  if (toastTimer) clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
    toast.classList.add("hide");
    setTimeout(() => toast.classList.add("hidden"), 180);
  }, 1800);
}

function sanitizeState(value) {
  return (value || "").trim().toUpperCase().slice(0, 2);
}

function getCheckoutPayload() {
  const cart = getCart();

  return {
    customer: {
      name: getInputValue("checkoutName"),
      email: getInputValue("checkoutEmail").toLowerCase(),
      phone: onlyDigits(getInputValue("checkoutPhone"))
    },
    shipping_address: {
      street: getInputValue("checkoutStreet"),
      number: getInputValue("checkoutNumber"),
      city: getInputValue("checkoutCity"),
      state: sanitizeState(getInputValue("checkoutState")),
      zip_code: onlyDigits(getInputValue("checkoutZip"))
    },
    items: cart.map((item) => ({
      product_id: Number(item.id),
      quantity: Number(item.quantity)
    }))
  };
}

function validateCheckoutPayload(payload) {
  if (!payload.items.length) {
    throw new Error("Sua sacola está vazia.");
  }

  if (!payload.customer.name) throw new Error("Preencha o nome completo.");
  if (!payload.customer.email) throw new Error("Preencha o e-mail.");
  if (!payload.customer.phone) throw new Error("Preencha o telefone.");

  if (!payload.shipping_address.street) throw new Error("Preencha a rua.");
  if (!payload.shipping_address.number) throw new Error("Preencha o número.");
  if (!payload.shipping_address.city) throw new Error("Preencha a cidade.");
  if (!payload.shipping_address.state) throw new Error("Preencha o estado.");
  if (!payload.shipping_address.zip_code) throw new Error("Preencha o CEP.");

  if (payload.customer.phone.length < 10) {
    throw new Error("Telefone inválido.");
  }

  if (payload.shipping_address.zip_code.length !== 8) {
    throw new Error("CEP inválido.");
  }

  if (payload.shipping_address.state.length !== 2) {
    throw new Error("Estado inválido.");
  }
}

function updateCheckoutButtonState() {
  const checkoutBtn = document.getElementById("checkoutBtn");
  if (!checkoutBtn) return;

  const cart = getCart();
  const hasItems = cart.length > 0;

  checkoutBtn.disabled = isSubmittingCheckout || !hasItems;
  checkoutBtn.textContent = isSubmittingCheckout ? "Processando..." : CHECKOUT_BUTTON_DEFAULT_TEXT;

  if (!hasItems) {
    checkoutBtn.classList.add("opacity-60", "cursor-not-allowed");
  } else {
    checkoutBtn.classList.remove("opacity-60", "cursor-not-allowed");
  }
}

/* ===== Premium UI: badges + toast ===== */
function updateCartBadges() {
  const cart = getCart();
  const count = getCartCount(cart);

  const badge = document.getElementById("cartBadge");
  const badgeMobile = document.getElementById("cartBadgeMobile");

  const apply = (el) => {
    if (!el) return;
    if (count > 0) {
      el.textContent = String(count);
      el.classList.remove("hidden");
    } else {
      el.classList.add("hidden");
    }
  };

  apply(badge);
  apply(badgeMobile);
}

/* ===== Products render ===== */
function createColorDots(colors = []) {
  return colors
    .map(
      (color) => `
        <span
          class="w-3 h-3 rounded-full border border-zinc-400"
          style="background-color: ${color};"
          aria-hidden="true"
        ></span>
      `
    )
    .join("");
}

function getHoverImage(product) {
  const custom = (product.hoverImage || "").trim();
  return custom || DEFAULT_HOVER_IMAGE || product.image;
}

function createProductCard(product) {
  const hoverImage = getHoverImage(product);

  return `
    <article class="reveal group" data-speed="650">
      <div class="rounded-3xl bg-brand-card border border-black/5 px-5 py-6 md:px-6 md:py-7 text-center hover-lift h-full">
        <div class="h-5 flex justify-center items-center">
          <span class="w-px h-5 bg-brand-text/60"></span>
        </div>

        <h3 class="mt-4 text-lg md:text-xl font-semibold uppercase">${product.name}</h3>
        <p class="mt-1 text-xs md:text-sm">${formatPrice(product.price)}</p>

        <div class="mt-5 min-h-[110px] md:min-h-[140px] flex items-center justify-center">
          <div class="product-media relative w-full max-w-[280px] h-[110px] md:h-[140px]">
            <img
              src="${product.image}"
              alt="${product.name}"
              class="product-img product-img--main absolute inset-0 w-full h-full object-contain"
              loading="lazy"
            />
            <img
              src="${hoverImage}"
              alt="${product.name} (em uso)"
              class="product-img product-img--hover absolute inset-0 w-full h-full object-contain"
              loading="lazy"
              onerror="this.style.display='none';"
            />
          </div>
        </div>

        <div class="mt-4 flex justify-center gap-2">
          ${createColorDots(product.colors)}
        </div>

        <button
          type="button"
          class="add-to-cart-btn mt-5 inline-flex items-center justify-center border border-black px-5 py-3 text-[11px] md:text-xs uppercase tracking-[0.12em] hover:bg-black hover:text-white transition"
          data-product-id="${product.id}"
        >
          Adicionar
        </button>
      </div>
    </article>
  `;
}

function renderProducts() {
  const grid = document.getElementById("productsGrid");
  if (!grid) return;

  grid.innerHTML = products.map(createProductCard).join("");

  const addButtons = grid.querySelectorAll(".add-to-cart-btn");
  addButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const productId = Number(button.dataset.productId);
      addToCart(productId);
    });
  });
}

/* ===== Cart logic ===== */
function addToCart(productId) {
  const product = products.find((item) => item.id === productId);
  if (!product) return;

  const cart = getCart();
  const existingItem = findCartItem(cart, productId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1
    });
  }

  saveCart(cart);
  updateCartBadges();
  renderCart();
  showToast("Adicionado à sacola");
}

function increaseQty(productId) {
  const cart = getCart();
  const item = findCartItem(cart, productId);
  if (!item) return;

  item.quantity += 1;
  saveCart(cart);
  updateCartBadges();
  renderCart();
}

function decreaseQty(productId) {
  const cart = getCart();
  const item = findCartItem(cart, productId);
  if (!item) return;

  item.quantity -= 1;
  if (item.quantity <= 0) {
    const next = cart.filter((i) => i.id !== productId);
    saveCart(next);
  } else {
    saveCart(cart);
  }

  updateCartBadges();
  renderCart();
}

function removeFromCart(productId) {
  const cart = getCart().filter((item) => item.id !== productId);
  saveCart(cart);
  updateCartBadges();
  renderCart();
}

function clearCart() {
  saveCart([]);
  updateCartBadges();
  renderCart();
}

function getCartTotal(cart) {
  return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function renderCart() {
  const cartItemsContainer = document.getElementById("cartItems");
  const cartTotal = document.getElementById("cartTotal");

  if (!cartItemsContainer || !cartTotal) return;

  const cart = getCart();
  updateCartBadges();
  updateCheckoutButtonState();

  if (!cart.length) {
    cartItemsContainer.innerHTML = `
      <div class="py-8 text-center text-sm md:text-base text-zinc-500">
        Sua sacola está vazia.
      </div>
    `;
    cartTotal.textContent = formatPrice(0);
    return;
  }

  cartItemsContainer.innerHTML = cart
    .map(
      (item) => `
        <div class="flex items-center gap-4 rounded-2xl border border-black/10 p-3 md:p-4">
          <div class="w-20 h-16 md:w-24 md:h-20 shrink-0 flex items-center justify-center bg-zinc-50 rounded-xl">
            <img
              src="${item.image}"
              alt="${item.name}"
              class="max-h-12 md:max-h-14 w-auto object-contain"
            />
          </div>

          <div class="min-w-0 flex-1">
            <h4 class="text-sm md:text-base font-semibold uppercase truncate">${item.name}</h4>

            <div class="mt-2 flex items-center gap-2">
              <button
                type="button"
                class="qty-btn inline-flex items-center justify-center w-9 h-9 rounded-full border border-black/10 hover:bg-black hover:text-white transition"
                data-action="dec"
                data-product-id="${item.id}"
                aria-label="Diminuir quantidade"
                title="Diminuir"
              >−</button>

              <span class="min-w-[28px] text-center text-sm md:text-base">${item.quantity}</span>

              <button
                type="button"
                class="qty-btn inline-flex items-center justify-center w-9 h-9 rounded-full border border-black/10 hover:bg-black hover:text-white transition"
                data-action="inc"
                data-product-id="${item.id}"
                aria-label="Aumentar quantidade"
                title="Aumentar"
              >+</button>
            </div>

            <p class="mt-2 text-sm md:text-base font-medium">
              ${formatPrice(item.price * item.quantity)}
            </p>
          </div>

          <button
            type="button"
            class="remove-cart-item inline-flex items-center justify-center w-9 h-9 rounded-full border border-black/10 hover:bg-black hover:text-white transition"
            data-product-id="${item.id}"
            aria-label="Remover item"
            title="Remover item"
          >
            🗑
          </button>
        </div>
      `
    )
    .join("");

  cartTotal.textContent = formatPrice(getCartTotal(cart));

  const removeButtons = cartItemsContainer.querySelectorAll(".remove-cart-item");
  removeButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const productId = Number(button.dataset.productId);
      removeFromCart(productId);
    });
  });

  const qtyButtons = cartItemsContainer.querySelectorAll(".qty-btn");
  qtyButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const productId = Number(btn.dataset.productId);
      const action = btn.dataset.action;
      if (action === "inc") increaseQty(productId);
      if (action === "dec") decreaseQty(productId);
    });
  });
}

/* ===== Checkout ===== */
async function submitCheckout() {
  if (isSubmittingCheckout) return;

  const checkoutBtn = document.getElementById("checkoutBtn");

  try {
    const payload = getCheckoutPayload();
    validateCheckoutPayload(payload);

    isSubmittingCheckout = true;
    updateCheckoutButtonState();

    const response = await fetch("/checkout", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data?.detail || "Erro ao iniciar checkout.");
    }

    const checkoutUrl = data?.payment?.checkout_url;
    if (!checkoutUrl) {
      throw new Error("Resposta de pagamento inválida.");
    }

    if (checkoutBtn) {
      checkoutBtn.textContent = "Redirecionando...";
    }

    window.location.href = checkoutUrl;
  } catch (error) {
    console.error(error);
    showToast(error.message || "Erro ao processar checkout.");
    isSubmittingCheckout = false;
    updateCheckoutButtonState();
  }
}

/* ===== Modal cart ===== */
function setupCartModal() {
  const body = document.body;
  const cartModal = document.getElementById("cartModal");
  const cartOverlay = document.getElementById("cartOverlay");
  const cartCloseBtn = document.getElementById("cartCloseBtn");
  const cartTrigger = document.getElementById("cartTrigger");
  const cartTriggerMobile = document.getElementById("cartTriggerMobile");
  const clearCartBtn = document.getElementById("clearCartBtn");
  const checkoutBtn = document.getElementById("checkoutBtn");

  if (!cartModal) return;

  window.openCartModal = function () {
    cartModal.classList.remove("hidden");
    cartModal.setAttribute("aria-hidden", "false");
    body.classList.add("mobile-open");
  };

  window.closeCartModal = function () {
    cartModal.classList.add("hidden");
    cartModal.setAttribute("aria-hidden", "true");
    body.classList.remove("mobile-open");
  };

  if (cartTrigger) {
    cartTrigger.addEventListener("click", (event) => {
      event.preventDefault();
      renderCart();
      window.openCartModal();
    });
  }

  if (cartTriggerMobile) {
    cartTriggerMobile.addEventListener("click", () => {
      renderCart();
      window.openCartModal();
    });
  }

  if (cartOverlay) {
    cartOverlay.addEventListener("click", window.closeCartModal);
  }

  if (cartCloseBtn) {
    cartCloseBtn.addEventListener("click", window.closeCartModal);
  }

  if (clearCartBtn) {
    clearCartBtn.addEventListener("click", () => {
      clearCart();
      showToast("Sacola limpa");
    });
  }

  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", submitCheckout);
  }

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !cartModal.classList.contains("hidden")) {
      window.closeCartModal();
    }
  });
}

/* ===== Mobile menu ===== */
function setupMobileMenu() {
  const body = document.body;
  const menuBtn = document.getElementById("menuBtn");
  const mobileMenu = document.getElementById("mobileMenu");
  const menuIcon = document.getElementById("menuIcon");
  const mobileLinks = document.querySelectorAll(".mobile-link");

  if (!menuBtn || !mobileMenu || !menuIcon) return;

  const openMenu = () => {
    mobileMenu.classList.remove("hidden");
    menuBtn.setAttribute("aria-expanded", "true");
    menuIcon.textContent = "✕";
    body.classList.add("mobile-open");
  };

  const closeMenu = () => {
    mobileMenu.classList.add("hidden");
    menuBtn.setAttribute("aria-expanded", "false");
    menuIcon.textContent = "☰";
    body.classList.remove("mobile-open");
  };

  menuBtn.addEventListener("click", () => {
    const isOpen = !mobileMenu.classList.contains("hidden");
    if (isOpen) closeMenu();
    else openMenu();
  });

  mobileLinks.forEach((link) => {
    link.addEventListener("click", closeMenu);
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 1024) closeMenu();
  });
}

/* ===== Reveal on scroll ===== */
function setupRevealAnimation() {
  const revealItems = document.querySelectorAll(".reveal, [data-speed]");
  if (!revealItems.length) return;

  revealItems.forEach((item) => {
    const speed = item.dataset.speed;
    if (!speed) return;

    const ms = Number.parseInt(speed, 10);
    if (Number.isNaN(ms)) return;

    const clamped = Math.max(150, Math.min(159.900, ms));
    item.style.transitionDuration = `${clamped}ms`;
  });

  if (!("IntersectionObserver" in window)) {
    revealItems.forEach((item) => item.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  revealItems.forEach((item) => observer.observe(item));
}

/* ===== Header shrink on scroll ===== */
function setupHeaderShrink() {
  const shell = document.getElementById("headerShell");
  if (!shell) return;

  const threshold = 40;
  const onScroll = () => {
    if (window.scrollY > threshold) shell.classList.add("is-compact");
    else shell.classList.remove("is-compact");
  };

  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
}

/* ===== Return from Stripe ===== */
function handleStripeReturn() {
  const params = new URLSearchParams(window.location.search);
  const paymentStatus = params.get("pagamento");
  const sessionId = params.get("session_id");

  if (paymentStatus === "sucesso") {
    clearCart();
    if (typeof window.closeCartModal === "function") {
      window.closeCartModal();
    }
    showToast(sessionId ? "Pagamento iniciado com sucesso." : "Pagamento concluído.");
  }

  if (paymentStatus === "cancelado") {
    showToast("Pagamento cancelado. Sua sacola foi mantida.");
  }
}

/* ===== Init ===== */
document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  setupMobileMenu();
  setupCartModal();
  renderCart();
  updateCartBadges();
  updateCheckoutButtonState();
  setupHeaderShrink();
  setupRevealAnimation();
  handleStripeReturn();
});