from pathlib import Path
from typing import List
from datetime import datetime, timezone
from uuid import uuid4

import uvicorn
import stripe
from fastapi import FastAPI, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, EmailStr, Field

app = FastAPI()

# =========================
# CONFIG FIXA (DEV)
# =========================
APP_URL = "http://127.0.0.1:8033"

STRIPE_SECRET_KEY = "sk_test_51ReHHVCNpLFj9puViMniH3LYBROuBOVt7BECKa92EV7hVNchwkOeli7YGT14xpLlAz71lFNFjYdq22PmKmorMFFj00xa8RTz1v"
STRIPE_WEBHOOK_SECRET = "whsec_ea43fa968ea09b3c5a69fdbdb902c7588fe8bc7eb2e8a10a65eeba287f25d041"

stripe.api_key = STRIPE_SECRET_KEY

# =========================
# MONGO
# =========================
client = AsyncIOMotorClient(
    username="admin",
    password="admin",
    host="127.0.0.1",
    port=27017,
    authSource="admin",
    serverSelectionTimeoutMS=5000,
)
db = client.get_database("usuarios_zilli")
usuarios_carrinho_collection = db.get_collection("usuarios_carrinho")

# =========================
# FRONTEND
# =========================
BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

app.mount("/static", StaticFiles(directory=FRONTEND_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(FRONTEND_DIR / "templates"))

# =========================
# CATÁLOGO MOCKADO / FONTE DE VERDADE DO BACKEND
# =========================
PRODUCTS_DB = {
    1: {"name": "Óculos 1", "price": 159.90, "sku": "OCULOS-001"},
    2: {"name": "Óculos 2", "price": 159.90, "sku": "OCULOS-002"},
    3: {"name": "Óculos 3", "price": 159.90, "sku": "OCULOS-003"},
    4: {"name": "Óculos 4", "price": 159.90, "sku": "OCULOS-004"},
    5: {"name": "Óculos 5", "price": 159.90, "sku": "OCULOS-005"},
    6: {"name": "Óculos 6", "price": 159.90, "sku": "OCULOS-006"},
    7: {"name": "Óculos 7", "price": 159.90, "sku": "OCULOS-007"},
    8: {"name": "Óculos 8", "price": 159.90, "sku": "OCULOS-008"},
    9: {"name": "Óculos 9", "price": 159.90, "sku": "OCULOS-009"},
}

# =========================
# SCHEMAS
# =========================
class CheckoutItem(BaseModel):
    product_id: int
    quantity: int = Field(gt=0, le=20)


class CustomerData(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    phone: str = Field(min_length=8, max_length=20)


class ShippingAddress(BaseModel):
    street: str = Field(min_length=2, max_length=120)
    number: str = Field(min_length=1, max_length=20)
    city: str = Field(min_length=2, max_length=80)
    state: str = Field(min_length=2, max_length=2)
    zip_code: str = Field(min_length=8, max_length=12)


class CheckoutRequest(BaseModel):
    customer: CustomerData
    shipping_address: ShippingAddress
    items: List[CheckoutItem]


# =========================
# HELPERS
# =========================
def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def generate_order_reference() -> str:
    return f"ORD-{uuid4().hex[:12].upper()}"


def normalize_phone(phone: str) -> str:
    return "".join(ch for ch in phone if ch.isdigit())


def normalize_zip_code(zip_code: str) -> str:
    return "".join(ch for ch in zip_code if ch.isdigit())


def normalize_state(state: str) -> str:
    return state.strip().upper()


def build_order_from_payload(payload: CheckoutRequest) -> dict:
    if not payload.items:
        raise HTTPException(status_code=400, detail="Carrinho vazio.")

    customer_name = payload.customer.name.strip()
    customer_email = payload.customer.email.strip().lower()
    customer_phone = normalize_phone(payload.customer.phone)

    street = payload.shipping_address.street.strip()
    number = payload.shipping_address.number.strip()
    city = payload.shipping_address.city.strip()
    state = normalize_state(payload.shipping_address.state)
    zip_code = normalize_zip_code(payload.shipping_address.zip_code)

    if len(customer_phone) < 10:
        raise HTTPException(status_code=400, detail="Telefone inválido.")

    if len(zip_code) != 8:
        raise HTTPException(status_code=400, detail="CEP inválido.")

    if len(state) != 2:
        raise HTTPException(status_code=400, detail="Estado inválido.")

    order_items = []
    subtotal = 0.0

    for item in payload.items:
        product = PRODUCTS_DB.get(item.product_id)
        if not product:
            raise HTTPException(
                status_code=400,
                detail=f"Produto inválido: {item.product_id}"
            )

        unit_price = float(product["price"])
        line_total = unit_price * item.quantity
        subtotal += line_total

        order_items.append({
            "product_id": item.product_id,
            "sku": product["sku"],
            "name": product["name"],
            "quantity": item.quantity,
            "unit_price": round(unit_price, 2),
            "line_total": round(line_total, 2),
        })

    shipping_cost = 0.0
    total = subtotal + shipping_cost

    return {
        "customer": {
            "name": customer_name,
            "email": customer_email,
            "phone": customer_phone,
        },
        "shipping_address": {
            "street": street,
            "number": number,
            "city": city,
            "state": state,
            "zip_code": zip_code,
        },
        "order": {
            "items": order_items,
            "subtotal": round(subtotal, 2),
            "shipping_cost": round(shipping_cost, 2),
            "total": round(total, 2),
            "currency": "BRL",
        }
    }


def build_stripe_line_items(order_data: dict) -> list[dict]:
    line_items = []

    for item in order_data["order"]["items"]:
        unit_amount = int(round(float(item["unit_price"]) * 100))

        line_items.append({
            "price_data": {
                "currency": "brl",
                "product_data": {
                    "name": item["name"],
                    "metadata": {
                        "sku": item["sku"],
                        "product_id": str(item["product_id"]),
                    },
                },
                "unit_amount": unit_amount,
            },
            "quantity": item["quantity"],
        })

    return line_items


async def create_checkout_document(order_reference: str, order_data: dict, payment_session: dict) -> str:
    now = utcnow()

    document = {
        "order_reference": order_reference,
        "status": "pending_payment",
        "customer": order_data["customer"],
        "shipping_address": order_data["shipping_address"],
        "order": order_data["order"],
        "payment": {
            "provider": payment_session.get("provider", "stripe"),
            "session_id": payment_session.get("session_id"),
            "checkout_url": payment_session.get("checkout_url"),
            "status": payment_session.get("status", "open"),
            "payment_status": payment_session.get("payment_status", "unpaid"),
            "is_paid": False,
            "gateway_response": payment_session.get("gateway_response", {}),
        },
        "pedido_finalizado": False,
        "created_at": now,
        "updated_at": now,
        "paid_at": None,
    }

    result = await usuarios_carrinho_collection.insert_one(document)
    return str(result.inserted_id)


# =========================
# STARTUP
# =========================
@app.on_event("startup")
async def startup_indexes():
    try:
        await client.admin.command("ping")

        await usuarios_carrinho_collection.create_index("order_reference", unique=True)
        await usuarios_carrinho_collection.create_index("customer.email")
        await usuarios_carrinho_collection.create_index("payment.session_id", sparse=True)

        print("Mongo conectado e índices criados com sucesso.")
    except Exception as e:
        print(f"Erro ao iniciar Mongo/índices: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()


# =========================
# ROTAS
# =========================
@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/checkout")
async def checkout(payload: CheckoutRequest):
    order_data = build_order_from_payload(payload)
    order_reference = generate_order_reference()

    try:
        session = stripe.checkout.Session.create(
            mode="payment",
            client_reference_id=order_reference,
            customer_email=order_data["customer"]["email"],
            success_url=f"{APP_URL}/?pagamento=sucesso&session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{APP_URL}/?pagamento=cancelado",
            line_items=build_stripe_line_items(order_data),
            metadata={
                "order_reference": order_reference,
                "customer_email": order_data["customer"]["email"],
            },
            payment_intent_data={
                "metadata": {
                    "order_reference": order_reference,
                    "customer_email": order_data["customer"]["email"],
                }
            },
        )
    except stripe.error.StripeError as e:
        raise HTTPException(
            status_code=502,
            detail=getattr(e, "user_message", None) or str(e)
        )

    payment_session = {
        "provider": "stripe",
        "session_id": session.id,
        "checkout_url": session.url,
        "status": getattr(session, "status", "open"),
        "payment_status": getattr(session, "payment_status", "unpaid"),
        "gateway_response": {
            "payment_intent": getattr(session, "payment_intent", None),
            "customer": getattr(session, "customer", None),
        },
    }

    inserted_id = await create_checkout_document(
        order_reference=order_reference,
        order_data=order_data,
        payment_session=payment_session,
    )

    return {
        "ok": True,
        "message": "Checkout Stripe criado com sucesso.",
        "document_id": inserted_id,
        "order_reference": order_reference,
        "payment": {
            "provider": "stripe",
            "session_id": session.id,
            "checkout_url": session.url,
            "status": getattr(session, "status", "open"),
            "payment_status": getattr(session, "payment_status", "unpaid"),
        },
    }


@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if not sig_header:
        raise HTTPException(status_code=400, detail="Stripe-Signature ausente.")

    try:
        event = stripe.Webhook.construct_event(
            payload=payload,
            sig_header=sig_header,
            secret=STRIPE_WEBHOOK_SECRET,
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Payload inválido.")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Assinatura inválida.")

    event_type = event["type"]
    data = event["data"]["object"]
    now = utcnow()

    if event_type == "checkout.session.completed":
        order_reference = data.get("client_reference_id") or data.get("metadata", {}).get("order_reference")

        if order_reference:
            await usuarios_carrinho_collection.update_one(
                {"order_reference": order_reference},
                {
                    "$set": {
                        "status": "paid",
                        "pedido_finalizado": True,
                        "updated_at": now,
                        "paid_at": now,
                        "payment.provider": "stripe",
                        "payment.session_id": data.get("id"),
                        "payment.status": data.get("status"),
                        "payment.payment_status": data.get("payment_status"),
                        "payment.is_paid": True,
                        "payment.gateway_response.payment_intent": data.get("payment_intent"),
                        "payment.gateway_response.last_event_id": event.get("id"),
                    },
                    "$push": {
                        "payment.webhook_events": {
                            "event_id": event.get("id"),
                            "type": event_type,
                            "received_at": now,
                        }
                    },
                },
            )

    elif event_type == "checkout.session.expired":
        order_reference = data.get("client_reference_id") or data.get("metadata", {}).get("order_reference")

        if order_reference:
            await usuarios_carrinho_collection.update_one(
                {"order_reference": order_reference},
                {
                    "$set": {
                        "status": "payment_expired",
                        "updated_at": now,
                        "payment.status": data.get("status"),
                        "payment.payment_status": data.get("payment_status"),
                        "payment.gateway_response.last_event_id": event.get("id"),
                    },
                    "$push": {
                        "payment.webhook_events": {
                            "event_id": event.get("id"),
                            "type": event_type,
                            "received_at": now,
                        }
                    },
                },
            )

    return {"received": True}


@app.get("/usuarios-carrinho/{order_reference}")
async def get_checkout_by_reference(order_reference: str):
    document = await usuarios_carrinho_collection.find_one({"order_reference": order_reference})

    if not document:
        raise HTTPException(status_code=404, detail="Pedido não encontrado.")

    document["_id"] = str(document["_id"])
    return jsonable_encoder(document)


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8033,
        reload=True
    )