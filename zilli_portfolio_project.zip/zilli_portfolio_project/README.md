# ZILLI - Premium Eyewear E-commerce

Projeto de e-commerce desenvolvido para a marca ZILLI, com foco em estética premium, experiência do usuário e conversão de leads.

## Tecnologias utilizadas

### Frontend
- HTML5
- TailwindCSS
- CSS3
- JavaScript

### Backend
- Python
- FastAPI
- Uvicorn
- MongoDB
- Stripe API

## Funcionalidades
- Carrinho de compras
- Checkout integrado com Stripe
- Persistência de pedidos no MongoDB
- Interface responsiva
- Animações e microinterações
- Modal de carrinho
- Estrutura preparada para catálogo dinâmico

## Estrutura do projeto

backend/
- main.py

frontend/
- templates/
  - index.html
- static/
  - css/
    - style.css
  - js/
    - main.js

## Sobre as pastas img e produtos

As pastas de imagens e produtos foram removidas propositalmente para evitar exposição de assets proprietários e conteúdos privados da marca.

O objetivo deste repositório é demonstrar:
- Estrutura do projeto
- Arquitetura
- Organização de código
- Integrações
- Qualidade do frontend e backend

Os caminhos de imagens foram substituídos por placeholders apenas para fins de portfólio.

## Observações técnicas

Os arquivos `main.js` e `style.css` estão sendo utilizados ativamente pelo projeto:
- `main.js`: responsável pela renderização dos produtos, carrinho, checkout, animações e interações da interface.
- `style.css`: responsável pelas animações, responsividade, efeitos visuais e estilos complementares ao TailwindCSS.